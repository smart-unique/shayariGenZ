'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { MotionDiv, MotionH1 } from '../components/MotionWrapper'

export default function Settings() {
  // Removed code:
  // const [language, setLanguage] = useState('english')
  //
  // const toggleLanguage = () => {
  //   setLanguage(prev => prev === 'english' ? 'hindi' : 'english')
  // }

  return (
    <div className="container mx-auto px-4 py-8">
      <MotionH1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Settings
      </MotionH1>
      <MotionDiv
        className="bg-white rounded-lg shadow-lg p-6"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="space-y-6">
          <div className="space-y-2">
            <Link 
              href="https://sites.google.com/view/shayari-by-genz/home" 
              target="_blank"
              rel="noopener noreferrer" 
              className="block text-blue-500 hover:underline"
            >
              Privacy Policy
            </Link>
            <Link 
              href="https://sites.google.com/view/terms-and-conditiion-for-shayr/home" 
              target="_blank"
              rel="noopener noreferrer"
              className="block text-blue-500 hover:underline"
            >
              Terms and Conditions
            </Link>
          </div>
          
          <div className="pt-4 border-t">
            <h2 className="text-xl font-semibold mb-2">Contact Us</h2>
            <div className="space-y-2 text-gray-600">
              <p>Developer: Aman Sahu</p>
              <p>Email: <a href="mailto:Amanchanderi1234@gmail.com" className="text-blue-500 hover:underline">Amanchanderi1234@gmail.com</a></p>
            </div>
          </div>
        </div>
      </MotionDiv>
    </div>
  )
}

