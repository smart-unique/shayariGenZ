import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const familyShayaris = [
  { id: 1, text: "परिवार वो जगह है जहाँ प्यार बसता है,\nहर दिल में अपनों का वास होता है।", language: "hindi" },
  { id: 2, text: "माँ की ममता, पिता का प्यार,\nभाई की दोस्ती, बहन का दुलार।", language: "hindi" },
  { id: 3, text: "रिश्तों की डोर से बंधा है ये संसार,\nपरिवार है जीवन का आधार।", language: "hindi" },
  { id: 4, text: "घर की खुशियाँ सबसे प्यारी हैं,\nपरिवार की यादें न्यारी हैं।", language: "hindi" },
  { id: 5, text: "परिवार है वो पेड़ जिसकी जड़ें मजबूत हैं,\nइसी से जीवन के सारे सुख जुड़े हुए हैं।", language: "hindi" },
  { id: 6, text: "परिवार की खुशियां ही असली दौलत होती हैं, इसे संभाल कर रखना।", language: "hindi" },
  { id: 7, text: "मां का प्यार और पिता का सहारा, यही परिवार की सबसे बड़ी ताकत है।", language: "hindi" },
  { id: 8, text: "परिवार वह जड़ है, जिससे जीवन का हर फल जुड़ा होता है।", language: "hindi" },
  { id: 9, text: "जहां हर दिल में अपनेपन का एहसास हो, वही परिवार का सही अर्थ है।", language: "hindi" },
  { id: 10, text: "परिवार वो जगह है, जहां हर दुख खुशी में बदल जाता है।", language: "hindi" },
  { id: 11, text: "जो समय परिवार के साथ बिताते हैं, वही जीवन के सबसे खूबसूरत पल होते हैं।", language: "hindi" },
  { id: 12, text: "परिवार की अहमियत वो ही समझता है, जिसने इसे खो दिया हो।", language: "hindi" },
  { id: 13, text: "परिवार का प्यार वो छांव है, जो हर दुख को हल्का कर देती है।", language: "hindi" },
  { id: 14, text: "सच्चा सुख वहीं मिलता है, जहां परिवार साथ होता है।", language: "hindi" },
  { id: 15, text: "परिवार का हर सदस्य एक फूल है, जो मिलकर एक बगीचा बनाते हैं।", language: "hindi" },
  { id: 16, text: "जब परिवार साथ हो, तो मुश्किलें भी रास्ता बदल लेती हैं।", language: "hindi" },
  { id: 17, text: "परिवार वह आंगन है, जहां प्यार और विश्वास की नींव होती है।", language: "hindi" },
  { id: 18, text: "परिवार की हंसी में सुकून छुपा होता है।", language: "hindi" },
  { id: 19, text: "परिवार के बिना इंसान अधूरा होता है।", language: "hindi" },
  { id: 20, text: "जहां सबके चेहरे पर मुस्कान हो, वही परिवार की सही परिभाषा है।", language: "hindi" },
  { id: 21, text: "परिवार का प्यार वह अनमोल तोहफा है, जिसे शब्दों में बयान नहीं किया जा सकता।", language: "hindi" },
  { id: 22, text: "परिवार की दीवारें प्यार और भरोसे से बनी होती हैं।", language: "hindi" },
  { id: 23, text: "हर कठिनाई का सामना करने की ताकत परिवार से मिलती है।", language: "hindi" },
  { id: 24, text: "परिवार वह सहारा है, जो हर तूफान में आपको गिरने नहीं देता।", language: "hindi" },
  { id: 25, text: "परिवार का साथ ही असली खुशी की पहचान है।", language: "hindi" },
  { id: 26, text: "परिवार वह मंदिर है, जहां हर दिल में प्रेम और आस्था रहती है।", language: "hindi" },
  { id: 27, text: "परिवार की खुशबू वह है, जो हर दिल को महका देती है।", language: "hindi" },
  { id: 28, text: "परिवार के साथ बिताया हर पल अनमोल होता है।", language: "hindi" },
  { id: 29, text: "परिवार वह आकाश है, जिसमें हर सपना पूरा होता है।", language: "hindi" },
  { id: 30, text: "परिवार का प्यार वह जादू है, जो हर दर्द को मिटा देता है।", language: "hindi" },
  { id: 31, text: "परिवार का महत्व तभी समझ आता है, जब हम उससे दूर हो जाते हैं।", language: "hindi" },
  { id: 32, text: "परिवार की सीख ही जीवन का सबसे बड़ा आधार होती है।", language: "hindi" },
  { id: 33, text: "परिवार का प्यार वह धागा है, जो सबको जोड़े रखता है।", language: "hindi" },
  { id: 34, text: "परिवार वह आईना है, जिसमें आप अपनी सच्ची पहचान देख सकते हैं।", language: "hindi" },
  { id: 35, text: "परिवार का आशीर्वाद हर मुश्किल को आसान कर देता है।", language: "hindi" },
  { id: 36, text: "परिवार के साथ बिताया समय ही सबसे कीमती खजाना है।", language: "hindi" },
  { id: 37, text: "परिवार की दुआएं जीवन की सबसे बड़ी पूंजी हैं।", language: "hindi" },
  { id: 38, text: "परिवार के साथ होने से हर सपने को पंख मिलते हैं।", language: "hindi" },
  { id: 39, text: "परिवार का साथ वह छांव है, जिसमें हर दर्द छिप जाता है।", language: "hindi" },
  { id: 40, text: "परिवार की मुस्कान ही जीवन की असली सफलता है।", language: "hindi" },
  { id: 41, text: "परिवार का स्नेह वह अमृत है, जो जीवन को मीठा बनाता है।", language: "hindi" },
  { id: 42, text: "परिवार वह नींव है, जिस पर सफलता की इमारत खड़ी होती है।", language: "hindi" },
  { id: 43, text: "परिवार का प्यार हर जख्म पर मरहम जैसा होता है।", language: "hindi" },
  { id: 44, text: "परिवार के साथ होने से हर सपना सच हो सकता है।", language: "hindi" },
  { id: 45, text: "परिवार की दुआएं जीवन का सबसे बड़ा तोहफा हैं।", language: "hindi" },
  { id: 46, text: "परिवार का सहारा हर तूफान को पार करने की ताकत देता है।", language: "hindi" },
  { id: 47, text: "परिवार की एकजुटता ही सबसे बड़ी ताकत होती है।", language: "hindi" },
  { id: 48, text: "परिवार का प्यार वह ताकत है, जो आपको कभी गिरने नहीं देती।", language: "hindi" },
  { id: 49, text: "परिवार का प्यार वह छांव है, जिसमें हर सपना खिल उठता है।", language: "hindi" },
  { id: 50, text: "परिवार के बिना जीवन अधूरा और सूना लगता है।", language: "hindi" },
  { id: 51, text: "परिवार की देखभाल करना ही सबसे बड़ी जिम्मेदारी है।", language: "hindi" },
  { id: 52, text: "परिवार वह किताब है, जिसमें हर पन्ना अनमोल होता है।", language: "hindi" },
  { id: 53, text: "परिवार का प्यार कभी खत्म नहीं होता, वह हमेशा साथ रहता है।", language: "hindi" },
  { id: 54, text: "परिवार के बिना जीवन का हर रंग फीका है।", language: "hindi" },
  { id: 55, text: "परिवार की बातें हर दुख को हल्का कर देती हैं।", language: "hindi" }
]

export default function FamilyShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Family Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {familyShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

