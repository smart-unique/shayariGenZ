import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const sadShayaris = [
{ id: 1, text: "दिल टूटा है तो आँसू बहते हैं,\nयादों के पन्ने अब भी कहते हैं।", language: "hindi" },
{ id: 2, text: "तनहाई में डूबा हुआ ये दिल,\nतेरी यादों से भरा हुआ ये दिल।", language: "hindi" },
{ id: 3, text: "खामोशी में छुपी है दर्द की दास्तान,\nआँखों में बसी है प्यार की अरमान।", language: "hindi" },
{ id: 4, text: "बिखरे हुए सपनों की कहानी है ये,\nटूटे हुए दिल की जुबानी है ये।", language: "hindi" },
{ id: 5, text: "गम के सागर में डूबा हुआ ये जहान,\nयादों के पन्नों पर लिखा हुआ ये बयान।", language: "hindi" },
{ id: 6, text: "खुशियों की तलाश में हम गम ले आए, और गम ने हमें कहीं का ना छोड़ा।", language: "hindi" },
{ id: 7, text: "दिल तोड़ने वालों को ये नहीं पता, कि टूटे हुए दिल से भी दुआएं निकलती हैं।", language: "hindi" },
{ id: 8, text: "चाहने वाले हमेशा दर्द ही देते हैं, शायद यही मोहब्बत की रीत है।", language: "hindi" },
{ id: 9, text: "जिनके लिए हमने अपनी दुनिया छोड़ दी, उन्होंने ही हमें अकेला छोड़ दिया।", language: "hindi" },
{ id: 10, text: "हर आंसू एक कहानी कहता है, मगर सुनने वाला कोई नहीं होता।", language: "hindi" },
{ id: 11, text: "मुस्कान के पीछे छुपे दर्द को कोई नहीं समझता।", language: "hindi" },
{ id: 12, text: "वो वादा करके भूल गए, और हम अब भी उनके लौटने की उम्मीद में हैं।", language: "hindi" },
{ id: 13, text: "जिंदगी ने हमें ऐसे मोड़ पर लाकर खड़ा कर दिया, जहां अपने ही बेगाने हो गए।", language: "hindi" },
{ id: 14, text: "दिल तो टूट चुका है, अब बस सांसें चल रही हैं।", language: "hindi" },
{ id: 15, text: "जो दर्द अंदर छुपा है, उसे कभी किसी को दिखाया नहीं।", language: "hindi" },
{ id: 16, text: "हम तो उनके इंतजार में बैठे रहे, और वो किसी और का हाथ थामकर चले गए।", language: "hindi" },
{ id: 17, text: "प्यार करके कोई गुनाह तो नहीं किया, फिर क्यों सजा मिली?", language: "hindi" },
{ id: 18, text: "तेरे जाने के बाद हर खुशी अधूरी सी लगती है।", language: "hindi" },
{ id: 19, text: "जिन्हें हमने अपना समझा, उन्होंने हमें पराया कर दिया।", language: "hindi" },
{ id: 20, text: "दर्द जब हद से गुजर जाता है, तो आंसू भी साथ छोड़ देते हैं।", language: "hindi" },
{ id: 21, text: "दिल को दर्द सहने की आदत हो गई है, मगर तुझे भुलाने की नहीं।", language: "hindi" },
{ id: 22, text: "जिंदगी में कुछ ऐसे लोग भी मिलते हैं, जो सिर्फ दर्द देकर चले जाते हैं।", language: "hindi" },
{ id: 23, text: "तेरी यादें आज भी मेरे साथ हैं, जैसे दर्द के निशान।", language: "hindi" },
{ id: 24, text: "दिल तो तेरा था, मगर दर्द मेरा हो गया।", language: "hindi" },
{ id: 25, text: "तेरे बिना ये जिंदगी अधूरी सी लगती है।", language: "hindi" },
{ id: 26, text: "दिल ने हर बार तुझसे प्यार किया, और हर बार टूट गया।", language: "hindi" },
{ id: 27, text: "हमने तो तुझे ही सब कुछ माना, और तुझे किसी और ने अपना माना।", language: "hindi" },
{ id: 28, text: "वो कहते हैं कि हमें भूल जाओ, पर ये दिल कैसे माने?", language: "hindi" },
{ id: 29, text: "जो अपने थे, उन्होंने ही हमें गैर समझ लिया।", language: "hindi" },
{ id: 30, text: "तेरी यादें मेरे साथ हैं, लेकिन तू मेरे पास नहीं।", language: "hindi" },
{ id: 31, text: "दिल टूटने की आवाज़ कोई नहीं सुनता, मगर दर्द हर कोई महसूस करता है।", language: "hindi" },
{ id: 32, text: "हम तो तुझसे प्यार करते रहे, मगर तुझे किसी और का इंतजार था।", language: "hindi" },
{ id: 33, text: "वो जो हमारे अपने थे, उन्होंने ही हमें अजनबी बना दिया।", language: "hindi" },
{ id: 34, text: "तेरे बिना ये जिंदगी काटनी है, जीनी नहीं।", language: "hindi" },
{ id: 35, text: "दिल तो करता है कि तुझे भूल जाऊं, मगर ये यादें मुझे रोक लेती हैं।", language: "hindi" },
{ id: 36, text: "हमने तो हर खुशी तुझ पर लुटा दी, और तूने हमें गम के सिवा कुछ नहीं दिया।", language: "hindi" },
{ id: 37, text: "प्यार में धोखा खाना अब हमारी आदत बन चुकी है।", language: "hindi" },
{ id: 38, text: "तूने जब मुझे छोड़ा, तब मेरी जिंदगी भी छूट गई।", language: "hindi" },
{ id: 39, text: "दिल ने जिसे चाहा, उसी ने हमें ठुकरा दिया।", language: "hindi" },
{ id: 40, text: "तेरे प्यार में सब कुछ खो दिया, और बदले में सिर्फ गम मिला।", language: "hindi" },
{ id: 41, text: "वो मुझसे खफा हो गए, और मैं खुद से।", language: "hindi" },
{ id: 42, text: "हर किसी से दिल लगाना सही नहीं होता, ये हमने तुझसे प्यार करके सीखा।", language: "hindi" },
{ id: 43, text: "तेरी हंसी ने दिल जीत लिया था, और तेरी बेवफाई ने उसे तोड़ दिया।", language: "hindi" },
{ id: 44, text: "तेरे प्यार का नशा अब भी चढ़ा है, मगर अब वो दर्द का हिस्सा बन चुका है।", language: "hindi" },
{ id: 45, text: "हम तो तुझ पर मरते थे, मगर तू किसी और पर मर मिटा।", language: "hindi" },
{ id: 46, text: "दिल को इतनी चोट पहुंचाई है, कि अब किसी पर भरोसा नहीं होता।", language: "hindi" },
{ id: 47, text: "तेरी बेवफाई ने मुझे खुद से दूर कर दिया।", language: "hindi" },
{ id: 48, text: "दिल ने हर दर्द सहा, मगर तुझे भुलाने की हिम्मत नहीं जुटा पाया।", language: "hindi" },
{ id: 49, text: "तू मेरे साथ होता, तो ये जिंदगी और भी खूबसूरत होती।", language: "hindi" },
{ id: 50, text: "तुझे याद करना अब मेरी आदत बन चुकी है।", language: "hindi" },
{ id: 51, text: "दिल तो करता है कि तुझसे सवाल करूं, मगर जवाब का डर सताता है।", language: "hindi" },
{ id: 52, text: "तेरे जाने के बाद मेरी मुस्कान भी मुझसे रूठ गई।", language: "hindi" },
{ id: 53, text: "तेरे प्यार के बिना ये जिंदगी अधूरी है।", language: "hindi" },
{ id: 54, text: "दिल ने तुझसे उम्मीदें लगाईं थीं, और तूने हर उम्मीद तोड़ दी।", language: "hindi" },
{ id: 55, text: "तेरे बिना जीने का हर पल बोझ सा लगता है।", language: "hindi" },

]

export default function SadShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Sad Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {sadShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

