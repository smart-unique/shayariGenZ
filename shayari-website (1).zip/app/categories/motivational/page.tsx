import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const motivationalShayaris = [
{ id: 1, text: "मंजिल मिलेगी, हिम्मत न हारो,\nकदम बढ़ाओ, रुकना न जानो।", language: "hindi" },
{ id: 2, text: "जीवन की राह में मुश्किलें आएंगी,\nहिम्मत से लड़ोगे तो खुशियाँ छाएंगी।", language: "hindi" },
{ id: 3, text: "सपनों को साकार करने की ठानी है,\nमेहनत से सफलता की कहानी है।", language: "hindi" },
{ id: 4, text: "हार कर भी न हारो हिम्मत,\nजीत तक चलती है ये किस्मत।", language: "hindi" },
{ id: 5, text: "अपने आप पर विश्वास रखो,\nहर मुश्किल को आसान बनाओ।", language: "hindi" },
{ id: 6, text: "हर मुश्किल को आसान बना लो, अपने हौसले की पहचान बना लो।", language: "hindi" },
{ id: 7, text: "अगर सपने बड़े हैं, तो मेहनत भी बड़ी करनी होगी।", language: "hindi" },
{ id: 8, text: "हारने वालों का नहीं, कोशिश करने वालों का नाम होता है।", language: "hindi" },
{ id: 9, text: "जिंदगी में जो भी पाना है, खुद पर भरोसा रखना।", language: "hindi" },
{ id: 10, text: "आसमान की बुलंदियों को छूने का हौसला रखो, क्योंकि सितारे कभी जमीन पर नहीं मिलते।", language: "hindi" },
{ id: 11, text: "सपनों को सच करना है, तो पहले खुद पर यकीन करना सीखो।", language: "hindi" },
{ id: 12, text: "मंजिल उन्हीं को मिलती है, जो हार नहीं मानते।", language: "hindi" },
{ id: 13, text: "रास्ते खुद बनते हैं, जब इरादे मजबूत होते हैं।", language: "hindi" },
{ id: 14, text: "जो खुद पर जीत हासिल कर लेता है, वही असली विजेता होता है।", language: "hindi" },
{ id: 15, text: "खुद की ताकत को पहचानो, मुश्किलें खुद आसान हो जाएंगी।", language: "hindi" },
{ id: 16, text: "हर कामयाबी के पीछे मेहनत की लंबी कहानी होती है।", language: "hindi" },
{ id: 17, text: "हार से मत घबराओ, क्योंकि हार ही जीत का पहला कदम है।", language: "hindi" },
{ id: 18, text: "कामयाबी पाने के लिए, खुद को हर दिन बेहतर बनाओ।", language: "hindi" },
{ id: 19, text: "मुश्किलें आती हैं, ताकि हम अपनी ताकत को पहचान सकें।", language: "hindi" },
{ id: 20, text: "सोच बड़ी रखो, सपने खुद बड़े हो जाएंगे।", language: "hindi" },
{ id: 21, text: "इंसान की पहचान उसकी मेहनत और सच्चाई से होती है।", language: "hindi" },
{ id: 22, text: "हर सुबह नई उम्मीद लेकर आती है, उसे गले लगाओ।", language: "hindi" },
{ id: 23, text: "जीतने का मजा तभी आता है, जब हारने का डर भी हो।", language: "hindi" },
{ id: 24, text: "कामयाबी की सीढ़ी पर चढ़ने के लिए धैर्य जरूरी है।", language: "hindi" },
{ id: 25, text: "जिंदगी में आगे बढ़ना है, तो पीछे मुड़कर देखने का समय नहीं।", language: "hindi" },
{ id: 26, text: "सपनों को सच करना है, तो मेहनत को अपना साथी बनाओ।", language: "hindi" },
{ id: 27, text: "जो मेहनत करता है, उसकी किस्मत खुद बदल जाती है।", language: "hindi" },
{ id: 28, text: "कामयाब वही होते हैं, जो समय की कदर करते हैं।", language: "hindi" },
{ id: 29, text: "अपनी मंजिल खुद तय करो, दूसरों की बातों में मत उलझो।", language: "hindi" },
{ id: 30, text: "जिंदगी में वही लोग सफल होते हैं, जो हार को स्वीकारते हैं।", language: "hindi" },
{ id: 31, text: "असफलता केवल एक अवसर है, सफलता को और बेहतर बनाने का।", language: "hindi" },
{ id: 32, text: "हर दिन एक नई शुरुआत का मौका होता है।", language: "hindi" },
{ id: 33, text: "जो लोग खुद पर विश्वास करते हैं, वही असंभव को संभव बना सकते हैं।", language: "hindi" },
{ id: 34, text: "खुद को कमजोर मत समझो, तुम में वो ताकत है जो दुनिया बदल सकती है।", language: "hindi" },
{ id: 35, text: "सपनों को साकार करने के लिए, हर रोज मेहनत करनी पड़ती है।", language: "hindi" },
{ id: 36, text: "हर जीत के पीछे धैर्य और मेहनत का हाथ होता है।", language: "hindi" },
{ id: 37, text: "सोच बदलो, दुनिया खुद-ब-खुद बदल जाएगी।", language: "hindi" },
{ id: 38, text: "मुश्किलें आपको बेहतर बनने का मौका देती हैं।", language: "hindi" },
{ id: 39, text: "जो खुद पर विश्वास करता है, वही अपने सपनों को पूरा कर सकता है।", language: "hindi" },
{ id: 40, text: "सफलता पाने के लिए दृढ़ निश्चय और अनुशासन जरूरी है।", language: "hindi" },
{ id: 41, text: "अपने हर काम में सर्वश्रेष्ठ देने की कोशिश करो।", language: "hindi" },
{ id: 42, text: "दूसरों से पहले खुद पर विश्वास करना सीखो।", language: "hindi" },
{ id: 43, text: "हर अंधेरा एक नई सुबह की शुरुआत करता है।", language: "hindi" },
{ id: 44, text: "जो लोग खुद को बदलते हैं, वही दुनिया को बदल सकते हैं।", language: "hindi" },
{ id: 45, text: "कामयाबी का पहला कदम है – खुद पर भरोसा।", language: "hindi" },
{ id: 46, text: "मंजिल तक पहुंचने के लिए रास्ते खुद बनते हैं।", language: "hindi" },
{ id: 47, text: "हर दिन एक नई उम्मीद लेकर आता है, बस उसे पहचानो।", language: "hindi" },
{ id: 48, text: "अपने सपनों को जीने का मजा ही कुछ और है।", language: "hindi" },
{ id: 49, text: "कामयाबी के लिए इंतजार नहीं, मेहनत करनी पड़ती है।", language: "hindi" },
{ id: 50, text: "जिंदगी में आगे बढ़ने के लिए, हर हार को सबक बनाओ।", language: "hindi" },
{ id: 51, text: "जो मुश्किलों से लड़ता है, वही असली योद्धा कहलाता है।", language: "hindi" },
{ id: 52, text: "हर असफलता सफलता की सीढ़ी है।", language: "hindi" },
{ id: 53, text: "खुद को इतना मजबूत बनाओ कि मुश्किलें भी हार मान लें।", language: "hindi" },
{ id: 54, text: "हार तब तक नहीं होती, जब तक आप खुद हार नहीं मानते।", language: "hindi" },
{ id: 55, text: "हर दिन नई चुनौती है, उसे स्वीकार करो और आगे बढ़ो।", language: "hindi" },

]

export default function MotivationalShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Motivational Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {motivationalShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

