import ShayariCard from '../../components/ShayariCard'
import { MotionDiv, MotionH1 } from '../../components/MotionWrapper'

const loveShayaris = [
{ id: 1, text: "तेरी याद आती है तो दिल धड़कता है,\nतेरे ख्याल से ही जीवन महकता है।", language: "hindi" },
{ id: 2, text: "मोहब्बत की राहों में कदम बढ़ाते हैं,\nतेरे साथ जीवन के सफर को सजाते हैं।", language: "hindi" },
{ id: 3, text: "तेरी आँखों में अपना चेहरा देखता हूँ,\nतेरी मुस्कान में अपनी खुशी ढूंढता हूँ।", language: "hindi" },
{ id: 4, text: "दिल की धड़कन में तेरा नाम बसा है,\nहर सांस में तेरा प्यार समा है।", language: "hindi" },
{ id: 5, text: "तेरे बिना जीवन अधूरा लगता है,\nतेरे साथ हर पल पूरा लगता है।", language: "hindi" },
{ id: 6, text: "तुमसे मिलकर ऐसा लगा जैसे प्यार को नई परिभाषा मिल गई।", language: "hindi" },
{ id: 7, text: "तेरे बिना ज़िंदगी अधूरी है, जैसे चाँद बिना चांदनी।", language: "hindi" },
{ id: 8, text: "मोहब्बत के रंग में डूबे हम, अब हर जगह बस तेरा नाम है।", language: "hindi" },
{ id: 9, text: "तुम्हारे बिना दिल का हाल ऐसा है, जैसे गिटार के बिना संगीत।", language: "hindi" },
{ id: 10, text: "हर सांस में बस तेरा ही एहसास है, तू ही मेरी दुनिया, तू ही मेरे पास है।", language: "hindi" },
{ id: 11, text: "प्यार का सफर शुरू हुआ, जब तुम्हारी मुस्कान ने मेरा दिल चुरा लिया।", language: "hindi" },
{ id: 12, text: "तेरे बिना ये जिंदगी अधूरी सी लगती है, जैसे कहानी बिना अंत।", language: "hindi" },
{ id: 13, text: "तुम्हारी बाहों में जैसे सारा जहान सिमट आया हो।", language: "hindi" },
{ id: 14, text: "इश्क में डूबे हम, अब तुझसे जुदा होना नामुमकिन है।", language: "hindi" },
{ id: 15, text: "तेरी हर एक मुस्कान मेरी खुशी का कारण बन जाती है।", language: "hindi" },
{ id: 16, text: "प्यार वो एहसास है, जिसमें हर दर्द भी मीठा लगता है।", language: "hindi" },
{ id: 17, text: "तुम्हारी बातों में जादू है, जो दिल को सुकून दे जाता है।", language: "hindi" },
{ id: 18, text: "तेरे बिना ये दिल उदास है, तू है तो सारी खुशियां पास हैं।", language: "hindi" },
{ id: 19, text: "तेरी मोहब्बत का खुमार अब हर वक्त मेरे सिर चढ़ा रहता है।", language: "hindi" },
{ id: 20, text: "तू मेरी धड़कन, तू मेरी जान है, मेरे दिल में बस तेरा ही नाम है।", language: "hindi" },
{ id: 21, text: "तेरे बिना ये जीवन अधूरा है, जैसे बिना धूप के दिन।", language: "hindi" },
{ id: 22, text: "प्यार वो है, जो हर बार नई उम्मीद देता है।", language: "hindi" },
{ id: 23, text: "तुम्हारी हंसी में सारा जहान सिमट जाता है।", language: "hindi" },
{ id: 24, text: "तेरी यादों का बसेरा अब मेरे दिल में बसता है।", language: "hindi" },
{ id: 25, text: "प्यार का सफर तब शुरू हुआ, जब मैंने तुम्हारी आँखों में अपना अक्स देखा।", language: "hindi" },
{ id: 26, text: "तेरे बिना जिंदगी अधूरी लगती है, जैसे बिना पंख के परिंदा।", language: "hindi" },
{ id: 27, text: "तू वो ख्वाब है, जिसे देखने के लिए मैं हर रात जागता हूं।", language: "hindi" },
{ id: 28, text: "तेरे बिना ये दिल तन्हा सा लगता है, जैसे बिना बरसात के बादल।", language: "hindi" },
{ id: 29, text: "तेरी मोहब्बत के रंग में रंग गया हूं, अब हर जगह बस तू ही तू नजर आता है।", language: "hindi" },
{ id: 30, text: "तू मेरी खुशियों का आधार है, मेरे सपनों का संसार है।", language: "hindi" },
{ id: 31, text: "तेरे बिना ये जीवन अधूरा है, जैसे बिना धड़कन के दिल।", language: "hindi" },
{ id: 32, text: "तेरी मोहब्बत में हर दर्द भी मीठा लगता है।", language: "hindi" },
{ id: 33, text: "तेरी बातों में वो जादू है, जो हर गम को भुला देता है।", language: "hindi" },
{ id: 34, text: "प्यार वो एहसास है, जिसमें हर पल खुशी और सुकून मिलता है।", language: "hindi" },
{ id: 35, text: "तेरे साथ हर लम्हा जैसे एक नई कहानी बुनता है।", language: "hindi" },
{ id: 36, text: "तू मेरी दुनिया का वो हिस्सा है, जिसे मैं हर हाल में बचाना चाहता हूं।", language: "hindi" },
{ id: 37, text: "तेरे बिना इस दिल का हर कोना वीरान है।", language: "hindi" },
{ id: 38, text: "तू मेरे ख्वाबों का वो सितारा है, जो हर रात चमकता है।", language: "hindi" },
{ id: 39, text: "तेरे बिना ये दिल बेजान है, जैसे बिना सांसों के शरीर।", language: "hindi" },
{ id: 40, text: "तेरी मोहब्बत का खुमार अब हर वक्त मेरे सिर पर छाया रहता है।", language: "hindi" },
{ id: 41, text: "तेरे बिना मेरी दुनिया अधूरी है, जैसे बिना सूरज के सुबह।", language: "hindi" },
{ id: 42, text: "तेरी मोहब्बत ने मेरी जिंदगी को एक नया अर्थ दिया।", language: "hindi" },
{ id: 43, text: "प्यार वो है, जो हर खुशी को दोगुना और हर गम को आधा कर देता है।", language: "hindi" },
{ id: 44, text: "तेरे साथ बिताए हर पल मेरे लिए एक अनमोल खजाना है।", language: "hindi" },
{ id: 45, text: "तू मेरी जिंदगी का वो हिस्सा है, जिसे मैं हर वक्त संभाल कर रखना चाहता हूं।", language: "hindi" },
{ id: 46, text: "तेरे बिना मेरी दुनिया वीरान है, जैसे बिना फूलों का बाग।", language: "hindi" },
{ id: 47, text: "प्यार में जो सुकून मिलता है, वो किसी और चीज में नहीं।", language: "hindi" },
{ id: 48, text: "तेरी मोहब्बत ने मेरी दुनिया बदल दी।", language: "hindi" },
{ id: 49, text: "तेरे बिना ये दिल अधूरा है, जैसे बिना पंख का परिंदा।", language: "hindi" },
{ id: 50, text: "तेरी हर मुस्कान मेरी खुशी का कारण बनती है।", language: "hindi" },
{ id: 51, text: "तेरे बिना इस दिल को चैन नहीं आता, जैसे बिना बारिश के सावन।", language: "hindi" },
{ id: 52, text: "प्यार का सफर तब शुरू हुआ, जब मैंने पहली बार तुम्हारी आंखों में झांका।", language: "hindi" },
{ id: 53, text: "तू मेरी हर खुशी का कारण है, मेरे हर सपने का आधार है।", language: "hindi" },
{ id: 54, text: "तेरी मोहब्बत का जादू अब हर वक्त मेरे सिर चढ़ा रहता है।", language: "hindi" },
{ id: 55, text: "प्यार वो एहसास है, जो हर वक्त दिल में बसे रहता है।", language: "hindi" },

]

export default function LoveShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <MotionH1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Love Shayaris
      </MotionH1>
      <div className="grid gap-6">
        {loveShayaris.map((shayari) => (
          <MotionDiv
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </MotionDiv>
        ))}
      </div>
    </div>
  )
}

