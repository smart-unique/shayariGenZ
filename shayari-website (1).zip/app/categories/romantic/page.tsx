import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const romanticShayaris = [
{ id: 1, text: "तेरे प्यार में डूबा हुआ ये दिल,\nतेरी याद में खोया हुआ ये दिल।", language: "hindi" },
{ id: 2, text: "चाँद की चाँदनी में तेरा चेहरा देखूँ,\nतारों की रोशनी में तेरी मुस्कान ढूँढूँ।", language: "hindi" },
{ id: 3, text: "तेरे साथ हर पल खूबसूरत लगता है,\nतेरे बिना हर लम्हा अधूरा लगता है।", language: "hindi" },
{ id: 4, text: "तेरी आँखों में अपना जह��न देखता हूँ,\nतेरी बाहों में अपना आशियान ढूँढता हूँ।", language: "hindi" },
{ id: 5, text: "तेरे इश्क में दीवाना हो गया हूँ,\nतेरे प्यार में मस्ताना हो गया हूँ।", language: "hindi" },
{ id: 6, text: "प्यार वो ताकत है, जो हर मुश्किल को आसान बना देती है।", language: "hindi" },
{ id: 7, text: "सपने तेरे साथ के हैं, इसलिए हर सपना पूरा करने की हिम्मत रखता हूं।", language: "hindi" },
{ id: 8, text: "तेरा साथ मेरे हर डर को खत्म कर देता है, जैसे सुबह का सूरज अंधेरों को।", language: "hindi" },
{ id: 9, text: "जब तुम साथ हो, तो हर मुश्किल को जीतने का जज्बा जाग जाता है।", language: "hindi" },
{ id: 10, text: "तेरे प्यार ने मुझे सिखाया, कि हार मानने वालों को कुछ नहीं मिलता।", language: "hindi" },
{ id: 11, text: "तेरी मुस्कान वो प्रेरणा है, जो मुझे हर दिन कुछ नया करने का हौसला देती है।", language: "hindi" },
{ id: 12, text: "तेरा साथ है, तो हर रास्ता आसान लगता है।", language: "hindi" },
{ id: 13, text: "तेरे प्यार की ताकत से मैं हर मंजिल तक पहुंच सकता हूं।", language: "hindi" },
{ id: 14, text: "प्यार और मेहनत का संगम हो, तो हर ख्वाब पूरा हो सकता है।", language: "hindi" },
{ id: 15, text: "तेरे साथ हर चुनौती को पार करने का हौसला मिलता है।", language: "hindi" },
{ id: 16, text: "प्यार में वो जादू है, जो इंसान को मजबूत बना देता है।", language: "hindi" },
{ id: 17, text: "तेरे सपनों को पूरा करने की कसम ने मुझे कभी हारने नहीं दिया।", language: "hindi" },
{ id: 18, text: "तेरा प्यार मेरे लिए प्रेरणा है, जो हर गम को भुला देता है।", language: "hindi" },
{ id: 19, text: "जब तुम साथ होती हो, तो हर मुश्किल का हल मिल जाता है।", language: "hindi" },
{ id: 20, text: "तेरे साथ बिताया हर पल मुझे और बेहतर बनने की प्रेरणा देता है।", language: "hindi" },
{ id: 21, text: "तेरे प्यार का एहसास मेरी ताकत है, जो हर दर्द को सहने की हिम्मत देता है।", language: "hindi" },
{ id: 22, text: "तेरे साथ के बिना ये जिंदगी अधूरी लगती है, इसलिए हर जंग जीतनी जरूरी है।", language: "hindi" },
{ id: 23, text: "तेरा प्यार मेरे हर सपने को जीने की वजह है।", language: "hindi" },
{ id: 24, text: "तेरे साथ होने से हर ख्वाब सच करने की प्रेरणा मिलती है।", language: "hindi" },
{ id: 25, text: "तेरी हंसी मुझे हर बार नई उम्मीद देती है।", language: "hindi" },
{ id: 26, text: "तेरे प्यार की रोशनी से मेरी जिंदगी चमक उठी है।", language: "hindi" },
{ id: 27, text: "तेरी आंखों में देखता हूं तो अपने सारे डर खत्म हो जाते हैं।", language: "hindi" },
{ id: 28, text: "तेरा प्यार हर दर्द को सहने की ताकत देता है।", language: "hindi" },
{ id: 29, text: "तेरे साथ के बिना हर मंजिल अधूरी लगती है।", language: "hindi" },
{ id: 30, text: "तेरी मोहब्बत ने मुझे हर मुश्किल से लड़ने का हौसला दिया।", language: "hindi" },
{ id: 31, text: "प्यार और विश्वास वो ताकत हैं, जो हर मुश्किल को मिटा देती हैं।", language: "hindi" },
{ id: 32, text: "तेरी मोहब्बत मेरा हौसला है, जो हर मंजिल तक पहुंचा सकती है।", language: "hindi" },
{ id: 33, text: "तेरी बाहों में वो सुकून है, जो हर डर को भुला देता है।", language: "hindi" },
{ id: 34, text: "तेरे साथ हर मुश्किल का सामना करने की हिम्मत रखता हूं।", language: "hindi" },
{ id: 35, text: "तेरे साथ बिताया हर पल मुझे जिंदगी की असली सीख देता है।", language: "hindi" },
{ id: 36, text: "तेरा प्यार मेरे हर डर को खत्म कर देता है।", language: "hindi" },
{ id: 37, text: "तेरे साथ होने से हर अंधकार में रोशनी दिखती है।", language: "hindi" },
{ id: 38, text: "तेरे साथ होने से हर सपना हकीकत लगता है।", language: "hindi" },
{ id: 39, text: "तेरी मोहब्बत ने मुझे हर हार को जीत में बदलना सिखाया।", language: "hindi" },
{ id: 40, text: "तेरी आंखों में जो ख्वाब देखे हैं, उन्हें पूरा करने का हर संभव प्रयास करूंगा।", language: "hindi" },
{ id: 41, text: "तेरे बिना हर मंजिल अधूरी है, इसलिए तुझे पाने की हर कोशिश करूंगा।", language: "hindi" },
{ id: 42, text: "तेरा साथ मेरे हर कदम को सही दिशा देता है।", language: "hindi" },
{ id: 43, text: "तेरा प्यार मेरी प्रेरणा है, जो मुझे हर दिन बेहतर बनाता है।", language: "hindi" },
{ id: 44, text: "तेरे साथ हर मुश्किल आसान लगती है।", language: "hindi" },
{ id: 45, text: "तेरा प्यार मेरी ताकत है, जो हर जंग जीतने का हौसला देता है।", language: "hindi" },
{ id: 46, text: "तेरी मुस्कान वो जादू है, जो हर दर्द को खत्म कर देता है।", language: "hindi" },
{ id: 47, text: "तेरे साथ हर अंधेरे में रोशनी नजर आती है।", language: "hindi" },
{ id: 48, text: "तेरे प्यार ने मुझे हर मुश्किल से पार पाने की ताकत दी है।", language: "hindi" },
{ id: 49, text: "तेरे साथ से हर दिन एक नई शुरुआत का एहसास होता है।", language: "hindi" },
{ id: 50, text: "तेरे बिना हर ख्वाब अधूरा लगता है, इसलिए तुझे पाने की हर कोशिश करूंगा।", language: "hindi" },
{ id: 51, text: "तेरे साथ होने से हर दर्द को सहने का जज्बा मिल जाता है।", language: "hindi" },
{ id: 52, text: "तेरा प्यार मेरे लिए वो सुकून है, जो हर मुश्किल को भुला देता है।", language: "hindi" },
{ id: 53, text: "तेरे साथ हर ख्वाब पूरा करने की हिम्मत मिलती है।", language: "hindi" },
{ id: 54, text: "तेरी मोहब्बत मेरी मंजिल को पाने का रास्ता है।", language: "hindi" },
{ id: 55, text: "तेरे साथ हर जीत को सेलिब्रेट करने का मौका मिलता है।", language: "hindi" },

]

export default function RomanticShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Romantic Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {romanticShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

