import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const friendshipShayaris = [
  { id: 1, text: "दोस्ती एक ऐसा रिश्ता है जो दिल से जुड़ा है,\nहर मुश्किल में साथ देने का वादा है।", language: "hindi" },
  { id: 2, text: "यारी की राह में कदम बढ़ाते हैं,\nदोस्त के लिए जान भी लुटाते हैं।", language: "hindi" },
  { id: 3, text: "दोस्ती का रिश्ता अनमोल होता है,\nहर पल साथ देने का मोल होता है।", language: "hindi" },
  { id: 4, text: "मित्रता की डोर से बंधे हैं हम,\nएक दूसरे के लिए जीते हैं हम।", language: "hindi" },
  { id: 5, text: "दोस्ती में न कोई शर्त होती है,\nन कोई हद होती है, बस अपनापन होता है।", language: "hindi" },
  { id: 6, text: "दोस्ती वो खूबसूरत रिश्ता है, जो दिल से दिल तक का सफर तय करता है।", language: "hindi" },
  { id: 7, text: "सच्ची दोस्ती वहीं होती है, जहां बिना कहे दिल की बात समझी जाती है।", language: "hindi" },
  { id: 8, text: "दोस्ती का हाथ थामो, क्योंकि ये वो रिश्ता है जो उम्र भर साथ देता है।", language: "hindi" },
  { id: 9, text: "दोस्ती के बिना जिंदगी अधूरी है, जैसे बिना रंगों के एक तस्वीर।", language: "hindi" },
  { id: 10, text: "दोस्ती का रिश्ता दुनिया के हर रिश्ते से अनमोल होता है।", language: "hindi" },
  { id: 11, text: "सच्चे दोस्त जिंदगी के हर मुश्किल पल को आसान बना देते हैं।", language: "hindi" },
  { id: 12, text: "दोस्ती वो रोशनी है, जो अंधेरे में भी रास्ता दिखाती है।", language: "hindi" },
  { id: 13, text: "जहां दोस्ती होती है, वहां हर पल खुशी का अहसास होता है।", language: "hindi" },
  { id: 14, text: "दोस्ती का मतलब है, बिना स्वार्थ के हमेशा साथ खड़ा रहना।", language: "hindi" },
  { id: 15, text: "सच्ची दोस्ती कभी खोती नहीं, वह वक्त के साथ और गहरी होती जाती है।", language: "hindi" },
  { id: 16, text: "दोस्ती वह आईना है, जिसमें सच्चाई और भरोसा झलकता है।", language: "hindi" },
  { id: 17, text: "जिनके पास सच्चे दोस्त होते हैं, वे कभी अकेले नहीं होते।", language: "hindi" },
  { id: 18, text: "दोस्ती का मतलब है हर खुशी और दुख में साथ रहना।", language: "hindi" },
  { id: 19, text: "दोस्ती वह रिश्ता है, जिसमें न कोई शर्त होती है, न कोई सीमा।", language: "hindi" },
  { id: 20, text: "दोस्ती के रंग इतने खूबसूरत होते हैं कि जिंदगी खुशनुमा हो जाती है।", language: "hindi" },
  { id: 21, text: "सच्चा दोस्त वो है, जो आपकी खामोशी में भी आपकी बातें सुन ले।", language: "hindi" },
  { id: 22, text: "दोस्ती का सफर हमेशा प्यार और विश्वास से भरा होता है।", language: "hindi" },
  { id: 23, text: "दोस्ती का असली मतलब है, बिना किसी उम्मीद के साथ निभाना।", language: "hindi" },
  { id: 24, text: "दोस्तों के बिना जिंदगी की किताब अधूरी है।", language: "hindi" },
  { id: 25, text: "सच्चे दोस्त आपकी मुस्कान की वजह होते हैं।", language: "hindi" },
  { id: 26, text: "दोस्ती वो रिश्ता है, जो हर दूरी को मिटा देता है।", language: "hindi" },
  { id: 27, text: "दोस्तों का साथ हर दर्द को खुशी में बदल देता है।", language: "hindi" },
  { id: 28, text: "दोस्ती का मतलब है, हर परिस्थिति में साथ रहना।", language: "hindi" },
  { id: 29, text: "सच्चे दोस्त आपकी कमजोरी नहीं, आपकी ताकत बनते हैं।", language: "hindi" },
  { id: 30, text: "दोस्ती वो छांव है, जो हर धूप से बचा लेती है।", language: "hindi" },
  { id: 31, text: "दोस्तों के बिना जिंदगी की मिठास अधूरी है।", language: "hindi" },
  { id: 32, text: "दोस्ती का रिश्ता इतना खास होता है, कि हर दिल उसे संभाल कर रखता है।", language: "hindi" },
  { id: 33, text: "सच्ची दोस्ती वक्त और हालात से परे होती है।", language: "hindi" },
  { id: 34, text: "दोस्ती का मतलब है हर मुश्किल में एक मजबूत कंधा मिलना।", language: "hindi" },
  { id: 35, text: "दोस्ती वह रिश्ता है, जो हर खुशी को दोगुना कर देता है।", language: "hindi" },
  { id: 36, text: "सच्ची दोस्ती हर तूफान को झेलने की ताकत देती है।", language: "hindi" },
  { id: 37, text: "दोस्ती का मतलब है, बिना कहे भी दिल की बात समझना।", language: "hindi" },
  { id: 38, text: "दोस्ती की चमक हर अंधेरे को रोशन कर देती है।", language: "hindi" },
  { id: 39, text: "सच्चा दोस्त वह है, जो हमेशा आपकी अच्छाई को बढ़ावा दे।", language: "hindi" },
  { id: 40, text: "दोस्ती का मतलब है, हर खुशी और दुख को बांटना।", language: "hindi" },
  { id: 41, text: "दोस्ती वह रिश्ता है, जो दिलों को जोड़ता है।", language: "hindi" },
  { id: 42, text: "सच्ची दोस्ती हर परिस्थिति में आपके साथ होती है।", language: "hindi" },
  { id: 43, text: "दोस्ती का मतलब है, हर मोड़ पर साथ देना।", language: "hindi" },
  { id: 44, text: "दोस्ती की बुनियाद भरोसे और प्यार ��र टिकी होती है।", language: "hindi" },
  { id: 45, text: "सच्चा दोस्त वह है, जो आपकी कमजोरियों को ताकत बना दे।", language: "hindi" },
  { id: 46, text: "दोस्ती का मतलब है, बिना स्वार्थ के साथ रहना।", language: "hindi" },
  { id: 47, text: "दोस्ती का रिश्ता दिल से बनता है, और दिल में ही बसता है।", language: "hindi" },
  { id: 48, text: "सच्ची दोस्ती वक्त के साथ और मजबूत होती है।", language: "hindi" },
  { id: 49, text: "दोस्ती का मतलब है, हर पल के लिए साथ रहना।", language: "hindi" },
  { id: 50, text: "दोस्ती वो है, जहां हर मुस्कान की वजह आपके दोस्त हों।", language: "hindi" },
  { id: 51, text: "सच्ची दोस्ती वह है, जो हर गिरावट में आपको उठाए।", language: "hindi" },
  { id: 52, text: "दोस्ती का मतलब है, हर खुशी और दुख में बिना किसी शर्त के साथ रहना।", language: "hindi" },
  { id: 53, text: "सच्चे दोस्त कभी दूर नहीं जाते, वह हर दिल की धड़कन में रहते हैं।", language: "hindi" },
  { id: 54, text: "दोस्ती का मतलब है, बिना कहे सब समझ लेना।", language: "hindi" },
  { id: 55, text: "सच्ची दोस्ती हर मुश्किल को आसान बना देती है।", language: "hindi" }
]

export default function FriendshipShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Friendship Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {friendshipShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

