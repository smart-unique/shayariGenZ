import Link from 'next/link'
import { MotionDiv, MotionH1 } from '../components/MotionWrapper'

const categories = [
  'Love', 'Sad', 'Friendship', 'Funny', 'Romantic', 'Broken', 'Family', 'Motivational', 'Spiritual', 'English'
]

export default function Categories() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <MotionH1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Categories
      </MotionH1>
      <div className="grid grid-cols-2 gap-4">
        {categories.map((category, index) => (
          <MotionDiv
            key={category}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Link href={`/categories/${category.toLowerCase()}`} className="block bg-white rounded-lg shadow-lg p-6 text-center hover:bg-blue-100 transition-colors">
              {category}
            </Link>
          </MotionDiv>
        ))}
      </div>
    </div>
  )
}

