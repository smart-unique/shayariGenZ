import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const spiritualShayaris = [
{ id: 1, text: "आत्मा की शांति में परमात्मा का वास है,\nध्यान में डूबे मन में प्रकाश है।", language: "hindi" },
{ id: 2, text: "जीवन की राह में आध्यात्म का दीप जलाओ,\nअंधकार मिटेगा, खुद को पहचानो।", language: "hindi" },
{ id: 3, text: "ईश्वर है कण-कण में, पहचानो उसे,\nप्रेम और करुणा से भरो अपने मन को।", language: "hindi" },
{ id: 4, text: "साधना की राह में चलो, मन को शांत करो,\nआत्मज्ञान की ज्योति से अपने जीवन को आलोकित करो।", language: "hindi" },
{ id: 5, text: "परमात्मा का नाम जपो, सब दुःख मिट जाएंगे,\nभक्ति के मार्ग पर चलो, सब सुख मिल जाएंगे।", language: "hindi" },
{ id: 6, text: "सुकून मिलता है जब ध्यान में बैठता हूं, ईश्वर के करीब होने का एहसास करता हूं।", language: "hindi" },
{ id: 7, text: "हर दिन एक नई प्रार्थना है, हर सांस एक नई भक्ति।", language: "hindi" },
{ id: 8, text: "ईश्वर का नाम लेने से ही दिल को शांति मिलती है।", language: "hindi" },
{ id: 9, text: "भक्ति की राह पर चलो, मोह-माया से दूर हो जाओ।", language: "hindi" },
{ id: 10, text: "जिंदगी का हर पल प्रभु को समर्पित करो, यही सच्ची सेवा है।", language: "hindi" },
{ id: 11, text: "जब तक ईश्वर पर भरोसा है, कोई संकट बड़ा नहीं लगता।", language: "hindi" },
{ id: 12, text: "हर कर्म को प्रभु के चरणों में अर्पण करो, यही सच्चा धर्म है।", language: "hindi" },
{ id: 13, text: "ईश्वर के बिना जीवन अधूरा है, उनकी भक्ति से ही पूर्णता है।", language: "hindi" },
{ id: 14, text: "हर सुबह प्रभु के नाम से शुरू करो, दिन भर आनंद मिलेगा।", language: "hindi" },
{ id: 15, text: "जो ईश्वर को अपने दिल में बसाता है, वो कभी अकेला नहीं रहता।", language: "hindi" },
{ id: 16, text: "भक्ति का दीप जलाओ, जीवन के अंधेरे को मिटाओ।", language: "hindi" },
{ id: 17, text: "कर्म करो लेकिन फल की चिंता मत करो, ईश्वर सब देखता है।", language: "hindi" },
{ id: 18, text: "सच का मार्ग ईश्वर तक पहुंचाता है, झूठ से दूर रखो।", language: "hindi" },
{ id: 19, text: "हर प्रार्थना में शक्ति है, हर भजन में सच्चाई।", language: "hindi" },
{ id: 20, text: "ईश्वर की कृपा से हर मुश्किल आसान हो जाती है।", language: "hindi" },
{ id: 21, text: "भगवान का स्मरण जीवन का सच्चा उद्देश्य है।", language: "hindi" },
{ id: 22, text: "ध्यान में बैठकर आत्मा की आवाज सुनो, वहीं ईश्वर है।", language: "hindi" },
{ id: 23, text: "प्रभु की मर्जी के बिना पत्ता भी नहीं हिलता।", language: "hindi" },
{ id: 24, text: "ईश्वर के नाम में वो शक्ति है, जो हर दुःख को हर ले।", language: "hindi" },
{ id: 25, text: "सच्ची भक्ति वही है, जो हर जीव में भगवान को देखे।", language: "hindi" },
{ id: 26, text: "मंदिर या मस्जिद नहीं, सच्चा भगवान तुम्हारे दिल में है।", language: "hindi" },
{ id: 27, text: "ईश्वर को पाने के लिए मन को शांत करना जरूरी है।", language: "hindi" },
{ id: 28, text: "हर सांस में प्रभु का नाम बसाओ, जीवन का आनंद बढ़ जाएगा।", language: "hindi" },
{ id: 29, text: "ईश्वर की भक्ति से ही सच्चा सुख मिलता है।", language: "hindi" },
{ id: 30, text: "जो ईश्वर पर विश्वास रखता है, वो कभी हार नहीं मानता।", language: "hindi" },
{ id: 31, text: "भगवान को पाना मुश्किल नहीं, बस सच्चे दिल से पुकारो।", language: "hindi" },
{ id: 32, text: "प्रभु का ध्यान ही जीवन का सबसे बड़ा धन है।", language: "hindi" },
{ id: 33, text: "ईश्वर के नाम की शक्ति हर संकट को मिटा देती है।", language: "hindi" },
{ id: 34, text: "जो सच्चे दिल से ईश्वर को पुकारता है, उसकी हर मुराद पूरी होती है।", language: "hindi" },
{ id: 35, text: "प्रभु का नाम जपना सबसे बड़ा कर्म है।", language: "hindi" },
{ id: 36, text: "भक्ति का दीपक जलाओ, जीवन की राह आसान हो जाएगी।", language: "hindi" },
{ id: 37, text: "प्रभु के बिना जीवन अधूरा है, उनकी भक्ति से ही सब कुछ पूर्ण है।", language: "hindi" },
{ id: 38, text: "हर दिल में भगवान का वास है, उसे पहचानना जरूरी है।", language: "hindi" },
{ id: 39, text: "सच्चे मन से की गई प्रार्थना कभी व्यर्थ नहीं जाती।", language: "hindi" },
{ id: 40, text: "प्रभु का नाम जपते जपते हर दर्द मिट जाता है।", language: "hindi" },
{ id: 41, text: "धर्म का मतलब केवल पूजा नहीं, बल्कि हर प्राणी से प्रेम है।", language: "hindi" },
{ id: 42, text: "प्रभु का स्मरण जीवन के हर गम को कम कर देता है।", language: "hindi" },
{ id: 43, text: "भगवान का आशीर्वाद हर संकट का समाधान है।", language: "hindi" },
{ id: 44, text: "जो प्रभु के चरणों में समर्पित है, उसे किसी से डरने की जरूरत नहीं।", language: "hindi" },
{ id: 45, text: "सच्चा भक्त वही है, जो हर खुशी और गम को भगवान की मर्जी समझे।", language: "hindi" },
{ id: 46, text: "प्रभु की भक्ति हर अंधकार को रोशनी में बदल देती है।", language: "hindi" },
{ id: 47, text: "ईश्वर की भक्ति से आत्मा को शांति मिलती है।", language: "hindi" },
{ id: 48, text: "भगवान के नाम में वो शक्ति है, जो हर असंभव को संभव बना दे।", language: "hindi" },
{ id: 49, text: "जो भगवान की राह पर चलता है, उसे मंजिल जरूर मिलती है।", language: "hindi" },
{ id: 50, text: "प्रभु का नाम हर दर्द को सहने की ताकत देता है।", language: "hindi" },
{ id: 51, text: "सच्चे मन से भगवान को याद करो, वो हमेशा तुम्हारे साथ हैं।", language: "hindi" },
{ id: 52, text: "ईश्वर की भक्ति ही सबसे बड़ी संपत्ति है।", language: "hindi" },
{ id: 53, text: "भगवान की शरण में जाने से हर डर खत्म हो जाता है।", language: "hindi" },
{ id: 54, text: "हर सुबह प्रभु के नाम से शुरू करो, दिन खुशहाल रहेगा।", language: "hindi" },
{ id: 55, text: "भगवान पर भरोसा रखो, वो हमेशा सही राह दिखाएंगे।", language: "hindi" },

]

export default function SpiritualShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Spiritual Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {spiritualShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

