import ShayariCard from '../../components/ShayariCard'
import { motion } from 'framer-motion'

const englishShayaris = [
  { id: 1, text: "In the garden of life, love blooms eternal,\nA fragrance that lingers, forever vernal.", language: "english" },
  { id: 2, text: "Whispers of the heart, silent yet loud,\nEchoing feelings, of which we're proud.", language: "english" },
  { id: 3, text: "Time flows like a river, swift and sure,\nMemories we cherish, forever pure.", language: "english" },
  { id: 4, text: "In the tapestry of fate, we're but a thread,\nWeaving stories of love, till we're dead.", language: "english" },
  { id: 5, text: "Stars in the sky, dreams in our eyes,\nReaching for hope, as time flies.", language: "english" },
  { id: 6, text: "The moonlight fades, but your memories shine brighter than the stars.", language: "english" },
  { id: 7, text: "In the silence of the night, your voice echoes in my heart.", language: "english" },
  { id: 8, text: "Love is a poem written on the pages of the soul, never fading.", language: "english" },
  { id: 9, text: "Even the flowers envy your beauty, for you are nature's masterpiece.", language: "english" },
  { id: 10, text: "Dreams of you light up my world, even in the darkest of times.", language: "english" },
  { id: 11, text: "Every heartbeat whispers your name, a rhythm of endless love.", language: "english" },
  { id: 12, text: "Love is a journey where two souls meet and walk hand in hand.", language: "english" },
  { id: 13, text: "Your eyes hold secrets the universe wishes it could keep.", language: "english" },
  { id: 14, text: "The rain kisses the earth, just as my heart longs for your touch.", language: "english" },
  { id: 15, text: "You are the melody my heart hums, a song of endless affection.", language: "english" },
  { id: 16, text: "A thousand sunsets cannot compare to the warmth of your smile.", language: "english" },
  { id: 17, text: "In your arms, I find a haven, a place where dreams come true.", language: "english" },
  { id: 18, text: "Time may pass, but the moments we shared remain eternal.", language: "english" },
  { id: 19, text: "Your love is the light that guides me through every storm.", language: "english" },
  { id: 20, text: "The world fades when I'm with you, for you are my entire universe.", language: "english" },
  { id: 21, text: "Your laughter is the symphony my heart dances to.", language: "english" },
  { id: 22, text: "The stars envy our love, for it shines brighter than their light.", language: "english" },
  { id: 23, text: "Love is not in words but in the silence we share together.", language: "english" },
  { id: 24, text: "Even in chaos, your love gives my soul its peace.", language: "english" },
  { id: 25, text: "Each tear I shed holds a memory of our love, deep and true.", language: "english" },
  { id: 26, text: "Your love is the treasure my heart searched for lifetimes.", language: "english" },
  { id: 27, text: "Even the winds carry your name, whispering it to my soul.", language: "english" },
  { id: 28, text: "In your love, I found the courage to rewrite my destiny.", language: "english" },
  { id: 29, text: "Love is a language the heart speaks, and only you understand mine.", language: "english" },
  { id: 30, text: "The beauty of your soul shines brighter than any sunrise.", language: "english" },
  { id: 31, text: "If love is a dream, then I never wish to wake from it.", language: "english" },
  { id: 32, text: "Your touch is magic, turning my fears into stars.", language: "english" },
  { id: 33, text: "Every heartbeat whispers your name, my eternal muse.", language: "english" },
  { id: 34, text: "In your eyes, I see the reflection of a love timeless and true.", language: "english" },
  { id: 35, text: "Love is not bound by time; it is felt in every moment with you.", language: "english" },
  { id: 36, text: "Your presence fills the voids my soul could not explain.", language: "english" },
  { id: 37, text: "A single smile from you can conquer all my sadness.", language: "english" },
  { id: 38, text: "Your love is the canvas where my soul paints its dreams.", language: "english" },
  { id: 39, text: "Even in silence, your heart speaks volumes to mine.", language: "english" },
  { id: 40, text: "Our love is like the ocean—vast, deep, and endless.", language: "english" },
  { id: 41, text: "In the melody of life, your love is the sweetest note.", language: "english" },
  { id: 42, text: "Your love is the sunshine that melts the frost in my heart.", language: "english" },
  { id: 43, text: "Even in my dreams, your love feels real and eternal.", language: "english" },
  { id: 44, text: "Your love is the poetry my heart recites endlessly.", language: "english" },
  { id: 45, text: "In your arms, I find a home where my heart can rest.", language: "english" },
  { id: 46, text: "Even the moon envies your radiance, for you light my darkest nights.", language: "english" },
  { id: 47, text: "Your love is the anchor that keeps my soul steady in storms.", language: "english" },
  { id: 48, text: "In the garden of life, your love is the most beautiful bloom.", language: "english" },
  { id: 49, text: "Even when apart, your love keeps my heart close to yours.", language: "english" },
  { id: 50, text: "With you, every moment feels like a miracle unfolding.", language: "english" },
  { id: 51, text: "In your love, I found the meaning my soul always sought.", language: "english" },
  { id: 52, text: "Your love is a flame that warms my coldest nights.", language: "english" },
  { id: 53, text: "Even in chaos, your love is the calm that soothes me.", language: "english" },
  { id: 54, text: "Your love is the bridge that connects my soul to eternity.", language: "english" },
  { id: 55, text: "In every heartbeat, I feel your love echoing through me.", language: "english" }
]

export default function EnglishShayaris() {
  return (
    <div className="container mx-auto px-4 py-8 mb-16">
      <motion.h1 
        className="text-4xl font-bold text-center mb-8 text-white"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        English Shayaris
      </motion.h1>
      <div className="grid gap-6">
        {englishShayaris.map((shayari) => (
          <motion.div
            key={shayari.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <ShayariCard shayari={shayari} />
          </motion.div>
        ))}
      </div>
    </div>
  )
}

